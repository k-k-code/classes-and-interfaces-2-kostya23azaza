package com.brunoyam.delivery.storage;

public class Gross extends Storage {

    int place;

    protected Gross(int place) {
        super(place);
    }


}