package com.brunoyam.delivery.storage;

public class Storage {
    int place;

    protected Storage(int place) {
        this.place = place;
    }


}
