package com.brunoyam.delivery.storage;

public class Retail {
}
