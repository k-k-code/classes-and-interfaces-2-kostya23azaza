package com.brunoyam.delivery.good;

public class Chairs extends Good {
    public Chairs(int price, int weight, int pack) {
        super(price, weight, pack);
    }
}
