package com.brunoyam.delivery.good;

public class Tables extends Good {
    public Tables(int price, int weight, int pack) {
        super(price, weight, pack);
    }
}