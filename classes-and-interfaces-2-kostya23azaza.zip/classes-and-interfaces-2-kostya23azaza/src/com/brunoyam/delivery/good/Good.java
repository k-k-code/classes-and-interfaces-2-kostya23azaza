package com.brunoyam.delivery.good;

public class Good {
    int price;
    int weight;
    int pack;


    protected Good(int price, int weight, int quant) {
        this.price = price;
        this.weight = weight;
        this.pack = quant;
    }

    public int getPrice() {
        return price;
    }

    public int getWeight() {
        return weight;
    }

    public int getPack() {
        return pack;
    }
}
