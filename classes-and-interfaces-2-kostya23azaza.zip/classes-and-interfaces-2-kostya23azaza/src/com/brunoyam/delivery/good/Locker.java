package com.brunoyam.delivery.good;

public class Locker extends Good {
    public Locker(int price, int weight, int pack) {
        super(price, weight, pack);
    }
}