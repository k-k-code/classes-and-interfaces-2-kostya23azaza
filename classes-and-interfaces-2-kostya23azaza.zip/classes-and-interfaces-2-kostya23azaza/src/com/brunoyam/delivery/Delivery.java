package com.brunoyam.delivery;

import com.brunoyam.delivery.Transport.Plane;
import com.brunoyam.delivery.Transport.Transport;
import com.brunoyam.delivery.good.Chairs;
import com.brunoyam.delivery.good.Good;
import com.brunoyam.delivery.good.Locker;
import com.brunoyam.delivery.good.Tables;


public class Delivery {

    private static int dist;

    protected Delivery(int dist) {
        this.dist = dist;
    }

    public static void main(String[] args) {
        dist = 5000;
        Good[] del1 = new Good[3];
        del1[0] = new Chairs(100, 2, 10);
        del1[1] = new Locker(300, 20, 3);
        del1[2] = new Tables(200, 8, 6);
        Plane plane = new Plane(1000, 800, 500);

        System.out.println(delPrice(dist, plane));
        System.out.println(delTime(dist, plane));
    }

    public static int delPrice(int dist, Transport transport) {
        int price = transport.getPrice();
        return (dist * price);
    }
          public static double delTime(int dist, Transport transport) {
                int speed = transport.getSpeed();
              return ((float) dist / (float) speed);
            }
    }

