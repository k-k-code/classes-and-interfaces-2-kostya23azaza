package com.brunoyam.delivery.Transport;

public class Truck extends Transport {
    public Truck(int load, int speed, int price) {
        super(load, speed, price);
    }
}



