package com.brunoyam.delivery.Transport;

public class Plane extends Transport {
    public Plane(int load, int speed, int price) {
        super(load, speed, price);
    }
}



