package com.brunoyam.delivery.Transport;

public class Transport {
    private int speed;
    private int load;
    private static int price;

    protected Transport(int load, int speed, int price) {
        this.load = load;
        this.price = price;
        this.speed = speed;
    }


    public int getSpeed() {
        return speed;
    }

    public int getLoad() {
        return load;
    }

    public static int getPrice() {
        return price;
    }
}
