package com.brunoyam.delivery.Transport;

public class Boat extends Transport {
    public Boat(int load, int speed, int price) {
        super(load, speed, price);
    }
}

